import logging
import azure.functions as func
from azure.storage.fileshare import ShareFileClient
import pandas as pd
import io
 
def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
 
    # ======== CONFIGURE YOUR STORAGE ACCOUNT ========
    storage_account_name = "staccredentialingusecase"
    file_share_name = "excelfiles"
    file_name = "AzureUsecaseInput.xlsx"
    storage_key = "U/wOQkoxswHgjosF6gTlxfUTnulpRUHJZiN9eSZarL8LXma+nDldF4EN8/MQVZ7OVaQt4mojG3NI+AStlzzP3g=="  # OR SAS token
 
    try:
        # Connect to file
        file_client = ShareFileClient(
            account_name=storage_account_name,
            share_name=file_share_name,
            file_path=file_name,
            credential=storage_key
        )
 
        # Download file into memory
        stream = io.BytesIO()
        file_client.download_file().readinto(stream)
        stream.seek(0)
 
        # Read Excel using pandas
        df = pd.read_excel(stream)
 
        # For demo: return first 5 rows as string
        return func.HttpResponse(df.head().to_json(), mimetype="application/json")
 
    except Exception as e:
        return func.HttpResponse(
            f"Error accessing Excel file: {str(e)}",
            status_code=500
        )
OLXTOTO | Referensi Bandar Togel Online & Paito SDY Akurat
OLXTOTO hadir sebagai referensi bandar togel online terpercaya dengan paito SDY yang akurat dan update harian untuk mendukung analisis angka.
 